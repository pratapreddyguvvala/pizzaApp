import { Component, OnInit, DoCheck, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';

import { interval } from 'rxjs';

@Component({
  selector: 'app-progress',
  templateUrl: './progress.component.html',
  styleUrls: ['./progress.component.css']
})
export class ProgressComponent implements OnInit{

details=[];
userDet={};
storageData;
CompletedOrders=[];
complete={};
key = '';
statusOrder;
keys;
EstimatedTime;
displayData;
timer ;
  ngOnInit() {


  let items = JSON.parse(localStorage.user);
  let HighOrder = items[items.length-1]['id']; 

    for (let i = 0; i < items.length; i++){
      this.userDet={};
      this.key = items[i]['id'];
     
      
     if(items[i]['status'] === '' && items[i]['status'] !== 'Completed'){
      let preparation = 5*(items[i]['items'][2].length);
       let Inoven = 120;
       let QualityCheck = 20;
       this.EstimatedTime = preparation+Inoven+QualityCheck;
       
     switch(this.key) {
        
      case HighOrder : 
      items[i]['status'] = 'Progress'
      items[i]['Time'] = 5;
      
      break;
      default: 
      items[i]['status'] = 'Waiting'
      items[i]['Time'] = this.EstimatedTime
      break;

    }
     
  }
      
  
  this.details.push(this.userDet);
  }
  localStorage.setItem('user', JSON.stringify(items));
  if(localStorage.user){
    this.displayData = JSON.parse(localStorage.user);
        }


  let statusRetrieve = JSON.parse(localStorage.user);

  for (let i = 0; i < statusRetrieve.length; i++){
    if(statusRetrieve[i]['status'] == 'Waiting'){
     
      setTimeout(() => {
        statusRetrieve[i]['status'] = 'Completed';
        statusRetrieve[i]['Time'] = '0';
       
         localStorage.setItem('user', JSON.stringify(statusRetrieve)); 
         if(localStorage.user){
          this.displayData = JSON.parse(localStorage.user);
              }
      
},this.EstimatedTime*1000);



   
  }
  else if(statusRetrieve[i]['status'] == 'Progress'){
   
    let preparation = 5*(statusRetrieve[i]['items'][2].length);
    let Inoven = 120;
    let QualityCheck = 20;
    this.EstimatedTime = preparation+Inoven+QualityCheck;
    setTimeout(() => {
      statusRetrieve[i]['status'] = 'Waiting';
      statusRetrieve[i]['Time'] = this.EstimatedTime;
     
       localStorage.setItem('user', JSON.stringify(statusRetrieve)); 
       if(localStorage.user){
        this.displayData = JSON.parse(localStorage.user);
            }
    
},50000);


 
}

}

    }
  
constructor(private roue: Router){}
}