import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PizzaHomePageComponent } from './pizza-home-page.component';
import { OrderComponent } from './order/order.component';
import { ProgressComponent } from './progress/progress.component';
import { CompletedOrderComponent } from './completed-order/completed-order.component';
import { ReportComponent } from './report/report.component';


const routes: Routes = [
{path: '',  component : PizzaHomePageComponent,children:
[
{path:'placeOrder', component: OrderComponent },
{path:'progress', component: ProgressComponent},
{path:'completed', component: CompletedOrderComponent},
{path:'report', component: ReportComponent}
]}
 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PizzHomePageRoutingModule { }
