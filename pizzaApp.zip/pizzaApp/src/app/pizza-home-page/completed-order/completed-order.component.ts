import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-completed-order',
  templateUrl: './completed-order.component.html',
  styleUrls: ['./completed-order.component.css']
})
export class CompletedOrderComponent implements OnInit {

  constructor() { }
  displayData= [];

key;
  ngOnInit() {
  
    if(localStorage.user){
      let data = JSON.parse(localStorage.user);
      for(let i=0;i<data.length;i++) {
        if(data[i]['status']==='Waiting' || data[i]['status']==='Completed') {
         
          this.displayData.push(data[i]);
        }
       
      }
          }
}
}
