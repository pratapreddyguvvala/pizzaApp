import { Component, OnInit,DoCheck, AfterViewInit, ViewEncapsulation } from '@angular/core';
import {FormGroup, FormControl, FormBuilder, Validators, ValidatorFn, AbstractControl} from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class OrderComponent implements OnInit, DoCheck,AfterViewInit {
  userForm: FormGroup;
  key;
  firstNameValue;
  lastNameValue;
  emailValue;
  phoneValue;
  selectCrustName;
  selectCrustValue;
  selectSauceName;
  selectSauceValue;
  nameTopping;
  valueTopping;
   typeTopping;
   status;
   Time;
 toppingTotal = 0;
 crustTotal = 0;
 sauceTotal = 0;
  priceTotal;
  selectedOptions;
  toppings = [];
  submitted = false;
  button = false;
  Total = 0;
  userArray = [];
  user = {};
  constructor(private fb : FormBuilder,private route: Router) {
  
  }
  ngOnInit() {
  
  
    this.userForm = this.fb.group({
      firstName: [],
      lastName: ['', Validators.required],
      email:['', [Validators.required,Validators.pattern("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+.[a-zA-Z]{2,3}$")]],
      phone: ['',[Validators.required, Validators.pattern('[9,8,7]{1}[0-9]{9}')]],
      selectCrust:['',Validators.required],
      selectSauce: ['', Validators.required],
      selectToppings: ['', [Validators.required,this.returnValidatorFunction]]
    })
   
  }
  ngAfterViewInit(){
   
  }
  optionChange(option){

this.toppingTotal =0;
this.toppings = [];
 this.selectedOptions = Array.apply(null,option)  // convert to real Array
 .filter(option => option.selected)
 .map(option => option.value)

 for(let i=0;i<this.selectedOptions.length;i++){
   let samp = this.selectedOptions[i].toString();
  
   this.typeTopping = samp.slice(4,7);
   this.nameTopping = samp.slice(7,-2);
   this.valueTopping = samp.slice(-2,-1);
   this.toppings.push({name:this.nameTopping,value:this.valueTopping,type:this.typeTopping});
   this.toppingTotal = this.toppingTotal + parseInt(this.valueTopping);
 
 }
  
   
    
  }
  get forms(){
   
    return this.userForm.controls;
  }
  
  returnValidatorFunction(control:FormControl){

    let selectedValues = control.value.length;
if(selectedValues<3){

  return {'lengthValid':true}
}
else{
  return null;
}
  }


ngDoCheck(){
  
  this.crustTotal = 0;
   this.sauceTotal = 0;
   this.status = '';
   this.Time = 0;
  this.firstNameValue = this.userForm.get('firstName').value;
  this.lastNameValue = this.userForm.get('lastName').value;
  this.emailValue = this.userForm.get('email').value;
  this.phoneValue = this.userForm.get('phone').value;;
  this.selectCrustName = this.userForm.get('selectCrust').value.slice(0,this.userForm.get('selectCrust').value.length-1);
 this.selectCrustValue = this.userForm.get('selectCrust').value.charAt(this.userForm.get('selectCrust').value.length-1);
 this.sauceTotal = this.sauceTotal+parseInt(this.selectSauceValue);
 this.selectSauceName = this.userForm.get('selectSauce').value.slice(0,this.userForm.get('selectSauce').value.length-1);
 this.selectSauceValue = this.userForm.get('selectSauce').value.charAt(this.userForm.get('selectSauce').value.length-1);
 this.crustTotal = this.crustTotal+parseInt(this.selectCrustValue);
if((this.sauceTotal + this.crustTotal + this.toppingTotal)!= NaN){
this.priceTotal = (this.sauceTotal + this.crustTotal + this.toppingTotal)+(0.1)*(this.sauceTotal + this.crustTotal + this.toppingTotal);
 
}
}
 



submit(){
 
    this.button = true;
  this.user['id']=new Date().getTime().toString();
  this.user['firstName'] = this.firstNameValue;
  this.user['lastName'] = this.lastNameValue;
  
  this.user['items'] = [{name:this.selectCrustName,value:this.selectCrustValue},{name: this.selectSauceName,value:this.selectSauceValue},this.toppings];
  this.user['status'] = this.status;
  this.user['Time'] = this.Time;
   
  if(localStorage.length == 0){
    this.userArray.push(this.user);
    localStorage.setItem('user', JSON.stringify(this.userArray));
  } else{
  for (let i = 0; i < localStorage.length; i++){
    this.key = localStorage.key(i);
  }
  let userRetrieveData = JSON.parse(localStorage.getItem(this.key));
  userRetrieveData.push(this.user);
  localStorage.setItem('user', JSON.stringify(userRetrieveData));
  
}
}
}
