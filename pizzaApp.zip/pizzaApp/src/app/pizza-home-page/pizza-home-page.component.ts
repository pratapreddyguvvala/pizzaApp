import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {MenuItem} from 'primeng/api';
import { Router } from '@angular/router';

@Component({
  selector: 'app-pizza-home-page',
  templateUrl: './pizza-home-page.component.html',
  styleUrls: ['./pizza-home-page.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class PizzaHomePageComponent implements OnInit {

  constructor(private route: Router) { }

 
  items: MenuItem[];
  activeItem: MenuItem;

  ngOnInit() {
      this.items = [
          {label: 'Place Order', icon: 'fa fa-fw fa-user'},
          {label: 'In Progress', icon: 'fa fa-fw fa-spinner'},
          {label: 'completed', icon: 'fa fa-fw fa-check'},
          {label: 'Report', icon: 'fa fa-fw fa-book'}
      ];
      this.activeItem = this.items[2];
  }
  tabClick(event){
    console.log(event.srcElement.innerText);
    switch(event.srcElement.innerText) {
      case 'Place Order': this.route.navigate(['placeOrder']);
      break;
        case 'In Progress':this.route.navigate(['progress']);
        break;
          case 'completed':this.route.navigate(['completed']);
          break;
            case 'Report':this.route.navigate(['report']);
            break;
          
    }
    
  }
  
}
