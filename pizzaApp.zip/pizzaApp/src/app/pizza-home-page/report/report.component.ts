import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {

progress= [];
Completed = [];
TotalNV= [];
nonVegUsers = 0;
vegUsers = 0;

displayData;
  constructor() { }

  ngOnInit() {
    this.displayData = JSON.parse(localStorage.user);
    
    
    for(let i=0;i<this.displayData.length;i++) {
      if(this.displayData[i]['status'] === 'Completed'){
        this.TotalNV.push(this.displayData[i]);
      let items = this.displayData[i]['items'];    
    
      for(let j=0;j<items[2].length;j++) {

         let checkNonVeg = items[2];

         for(let k=0;k<checkNonVeg.length;k++) {
             if (checkNonVeg[k]['type'] === 'Non') {
              this.nonVegUsers += 1;
              break;
             }
         }
        break;
      }

    }
    }

   
this.vegUsers = this.TotalNV.length - this.nonVegUsers;

for(let i=0;i<this.displayData.length;i++){
if(this.displayData[i]['status'] == 'Progress') {
this.progress.push(this.displayData[i]);
} else if(this.displayData[i]['status'] == 'Completed'){
  this.Completed.push(this.displayData[i]);
}
   }
   
  
  }
  
  
 
  }


