import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {TabMenuModule} from 'primeng/tabmenu';

import { PizzaHomePageComponent } from './pizza-home-page.component';
import {PizzHomePageRoutingModule} from './pizza-home-page-routing.module';
import { OrderComponent } from './order/order.component';
import { ProgressComponent } from './progress/progress.component';
import { CompletedOrderComponent } from './completed-order/completed-order.component';
import { ReportComponent } from './report/report.component';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import {DropdownModule} from 'primeng/dropdown';


@NgModule({
  declarations: [PizzaHomePageComponent, OrderComponent, ProgressComponent, CompletedOrderComponent, ReportComponent],
  imports: [
    CommonModule, TabMenuModule, PizzHomePageRoutingModule, FormsModule, ReactiveFormsModule, DropdownModule
  ]
})
export class PizzaHomePageModule { }
